# KaisFirstPackage/__init__.py

from .module_1 import add, subtract
from .module_2 import multiply, divide